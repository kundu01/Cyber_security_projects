class SearchProgress:
    def __init__(self) -> None:
        self.result_count = 0
        self.progress_percent = 0.0
